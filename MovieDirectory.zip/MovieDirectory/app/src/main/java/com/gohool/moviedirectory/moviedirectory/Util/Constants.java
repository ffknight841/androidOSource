package com.gohool.moviedirectory.moviedirectory.Util;

/**
 * Created by paulodichone on 4/12/17.
 */

public class Constants {

    //Not free anymore - I am paying $1USD/month for access
    //For now you can use this API Key, but please note that if too many people are using this
    // API, the app may time-out.
    //&apikey=cdc4cef5

    public static final String URL_LEFT = "http://www.omdbapi.com/?s=";
    public static final String URL = "http://www.omdbapi.com/?i=";
    public static final String API_KEY = "&apikey=cdc4cef5";
    public static final String URL_RIGHT = "&page=2";
}
